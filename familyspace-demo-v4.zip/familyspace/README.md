# familyspace demo

This version includes a shared server. Posts, alerts, reminders, completion status, chat messages, likes and location-sharing settings update on connected pages automatically, usually within one second.

## Start the demo

1. Install Python 3.10 or later if it is not already installed. No extra packages are needed.
2. Extract this folder and open a terminal in it.
3. Run `python3 server.py` (on Windows, `py server.py` also works).
4. Open http://localhost:8000 in your browser.
5. Open a second tab or browser window at the same address. Select different profiles using the top-right profile button.

You can also open specific demo profiles directly:

- Mom: http://localhost:8000/?profile=mom
- Dad: http://localhost:8000/?profile=dad
- Adam: http://localhost:8000/?profile=son
- Lina: http://localhost:8000/?profile=daughter

Each page keeps its selected profile. Switching one page does not switch other pages. These are selectable demo profiles; account sign-in is not implemented.

## Try the live updates

Open Mom in one page and Adam in another. In Mom's Feed, use the bell button to send an alert to Adam. It will appear in Adam's Feed and as an in-page popup, even if he is on a different app page. Other recipients are updated too. People who were not selected do not see the alert in their Feed.

Create a reminder for Adam, then mark it complete from Adam's Reminders page. The status updates for Mom as its creator. Try replying to a post, sending a chat message, or changing location sharing from a parent profile.

The page header shows SERVER CONNECTED when it is using the shared server. Keep the server running during the demo. If the connection drops, changes are queued in that tab and retried when the connection returns. Chat drafts and open creation forms are preserved when updates arrive.

## Use an iPhone, iPad or another computer

Connect the devices to the same Wi-Fi as the computer running the server. Find that computer's local network IP address and open `http://<computer-IP>:8000` on each device. Use the same address on every device. Allow the Python server through your computer's local-network firewall if prompted.

Opening localhost on a phone points at the phone itself. Use the server computer's IP address instead. Cross-network access would require hosting the included server; this download does not include a public hosted URL.

## Files and data

- `familyspace.html`: the responsive website.
- `server.py`: the shared HTTP server.
- `seed.json`: the original fictional family data.
- `.data/familyspace.sqlite3`: created when the server runs; it keeps changes across restarts.

Parents can delete any post or alert shown in their Feed. Children cannot delete posts or alerts, including their own. Delete buttons appear only for parents, and the server also checks the active demo profile. Deletions update all connected pages. A post already forwarded to Chat remains as a copied message.

Only parents can reset the demo. Reset demo restores the original fictional data for every connected page. It keeps each page's selected profile.

Opening the HTML without the included server uses browser storage where available. That mode can sync tabs under the same browser origin, but it does not sync different browsers or devices. The header identifies which mode is active.

Locations are fixed sample data. Alerts are in-page popups while the website is open; browser push notifications are not implemented.

## Validation

Checked the server with four independent JavaScript client sessions, including concurrent changes, recipient alerts, popup delivery, completion and undo, private-chat display, profile isolation, draft preservation, connection retry, duplicate requests, reset propagation and same-browser storage events. Also checked parent-only deletion controls, server rejection of child deletion requests, confirmation/cancel, deletion syncing across clients, and stale concurrent likes. Full browser layout testing was unavailable in the build environment.

## Check the updated page

The browser title and Feed profile card show Demo v4. The Feed has no New post button in its header. Use the existing Create a post field instead. Alerts and reminders both have a Select all button above their recipient names.

If you already have the demo running, stop it with Ctrl+C. Copy familyspace.html from this package into your existing server folder, replacing the previous file. Start the server again with py -X utf8 server.py, then refresh the browser with Ctrl+F5. Your .data folder holds your saved changes; keep it.

The earlier preview inside the chat is a separate copy. To see this version, use the updated download through your local server.
