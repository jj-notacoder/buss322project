#!/usr/bin/env python3
"""Shared familyspace demo server. Python 3.10+; no packages required."""
import argparse
import copy
import json
import sqlite3
import threading
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
MEMBERS = {'mom', 'dad', 'son', 'daughter'}
PARENTS = {'mom', 'dad'}
COLLECTIONS = {'posts', 'reminders', 'alerts', 'messages'}


class Store:
    def __init__(self, path):
        self.lock = threading.RLock()
        self.seed = json.loads((ROOT / 'seed.json').read_text(encoding='utf-8'))
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(path, check_same_thread=False)
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS document (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)')
        self.db.execute('CREATE TABLE IF NOT EXISTS mutations (id TEXT PRIMARY KEY)')
        if not self.db.execute('SELECT 1 FROM document').fetchone():
            self.db.execute('INSERT INTO document VALUES (1, ?)', (json.dumps({'revision': 0, 'generation': str(uuid.uuid4()), 'state': self.seed}),))
        self.db.commit()

    def read(self):
        with self.lock:
            return json.loads(self.db.execute('SELECT value FROM document WHERE id=1').fetchone()[0])

    def change(self, batch):
        if not isinstance(batch, dict):
            raise ValueError('Invalid change request')
        actor, mutation_id, ops = batch.get('actor'), batch.get('id'), batch.get('ops')
        if actor not in MEMBERS or not isinstance(mutation_id, str) or not 1 <= len(mutation_id) <= 100:
            raise ValueError('Invalid demo profile or request ID')
        if not isinstance(ops, list) or not 1 <= len(ops) <= 200:
            raise ValueError('Invalid changes')
        with self.lock:
            current = self.read()
            # Retries never duplicate a post, message or reset, including after restart.
            if self.db.execute('SELECT 1 FROM mutations WHERE id=?', (mutation_id,)).fetchone():
                return 200, current
            if batch.get('generation') != current['generation']:
                return 409, current
            data = copy.deepcopy(current['state'])
            reset = False
            for op in ops:
                if not isinstance(op, dict):
                    raise ValueError('Invalid operation')
                kind = op.get('kind')
                if kind == 'reset':
                    if actor not in PARENTS:
                        raise PermissionError('Only parents can reset the demo')
                    if len(ops) != 1:
                        raise ValueError('Reset must be a separate request')
                    data, reset = copy.deepcopy(self.seed), True
                elif kind == 'add':
                    collection, item = op.get('collection'), op.get('item')
                    if collection not in COLLECTIONS or not isinstance(item, dict):
                        raise ValueError('Invalid record')
                    self.validate_record(collection, item, actor)
                    if not any(row['id'] == item['id'] for row in data[collection]):
                        if collection in {'posts', 'alerts'}:
                            data[collection].insert(0, item)
                        else:
                            data[collection].append(item)
                elif kind == 'delete':
                    if actor not in PARENTS:
                        raise PermissionError('Only parents can delete posts and alerts')
                    collection, record_id = op.get('collection'), op.get('id')
                    if collection not in {'posts', 'alerts'} or not isinstance(record_id, str):
                        raise ValueError('Only posts and alerts can be deleted')
                    data[collection] = [row for row in data[collection] if row['id'] != record_id]
                elif kind == 'field':
                    # The current UI changes only a reminder's completion status.
                    if op.get('collection') != 'reminders' or op.get('field') != 'done' or type(op.get('value')) is not bool:
                        raise ValueError('Unsupported field change')
                    row = next((r for r in data['reminders'] if r['id'] == op.get('id')), None)
                    if row:
                        if actor != row['creator'] and actor not in row['recipients']:
                            raise ValueError('Reminder is not assigned to this profile')
                        row['done'] = op['value']
                elif kind == 'like':
                    if op.get('member') != actor or type(op.get('value')) is not bool:
                        raise ValueError('Invalid like')
                    row = next((r for r in data['posts'] if r['id'] == op.get('id')), None)
                    if row:
                        row['likes'] = [m for m in row['likes'] if m != actor]
                        if op['value']:
                            row['likes'].append(actor)
                elif kind == 'map':
                    if op.get('map') == 'sharing':
                        if actor not in PARENTS or op.get('key') not in MEMBERS or type(op.get('value')) is not bool:
                            raise ValueError('Only parent profiles can change location sharing')
                        data['sharing'][op['key']] = op['value']
                    elif op.get('map') == 'settings':
                        if op.get('key') != actor or op.get('field') != 'banners' or type(op.get('value')) is not bool:
                            raise ValueError('Invalid profile preference')
                        data['settings'].setdefault(actor, {})['banners'] = op['value']
                    else:
                        raise ValueError('Unsupported setting')
                else:
                    raise ValueError('Unsupported operation')
            result = {'revision': current['revision'] + 1,
                      'generation': str(uuid.uuid4()) if reset else current['generation'], 'state': data}
            with self.db:
                self.db.execute('UPDATE document SET value=? WHERE id=1', (json.dumps(result),))
                self.db.execute('INSERT INTO mutations VALUES (?)', (mutation_id,))
            return 200, result

    @staticmethod
    def validate_record(collection, item, actor):
        if not isinstance(item.get('id'), str) or not 1 <= len(item['id']) <= 100:
            raise ValueError('Invalid record ID')
        owner = 'creator' if collection == 'reminders' else 'author'
        if item.get(owner) != actor:
            raise ValueError('Record profile does not match the active profile')
        if collection in {'alerts', 'reminders'}:
            recipients = item.get('recipients')
            if not isinstance(recipients, list) or not recipients or any(m not in MEMBERS for m in recipients):
                raise ValueError('Choose valid recipients')
        if collection == 'reminders':
            if item.get('type') not in {'event', 'task'} or not isinstance(item.get('title'), str) or not item['title'].strip() or type(item.get('done')) is not bool:
                raise ValueError('Invalid reminder')
        if collection == 'posts':
            if not isinstance(item.get('caption'), str) or not isinstance(item.get('likes'), list) or item['likes']:
                raise ValueError('Invalid post')
            if item.get('image') and not str(item['image']).startswith('data:image/'):
                raise ValueError('Invalid image')
        if collection == 'messages':
            channel = item.get('channel', '')
            parts = channel.split('|') if isinstance(channel, str) else []
            if channel != 'group' and (len(parts) != 2 or len(set(parts)) != 2 or actor not in parts or any(p not in MEMBERS for p in parts)):
                raise ValueError('Invalid chat')
        if collection in {'alerts', 'messages'}:
            if not isinstance(item.get('text'), str) or not item['text'].strip() or len(item['text']) > 1500:
                raise ValueError('Invalid message')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def reply(self, status, body=None, content_type='application/json'):
        payload = b'' if body is None else (json.dumps(body).encode() if content_type == 'application/json' else body)
        self.send_response(status)
        self.send_header('Content-Type', content_type + '; charset=utf-8')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.end_headers()
        if payload:
            self.wfile.write(payload)

    def do_GET(self):
        url = urlparse(self.path)
        if url.path in {'/', '/familyspace.html'}:
            return self.reply(200, (ROOT / 'familyspace.html').read_bytes(), 'text/html')
        if url.path == '/api/state':
            current = self.server.store.read()
            query = parse_qs(url.query)
            if query.get('since') == [str(current['revision'])] and query.get('generation') == [current['generation']]:
                return self.reply(204)
            return self.reply(200, current)
        return self.reply(404, {'error': 'Not found'})

    def do_POST(self):
        if urlparse(self.path).path != '/api/changes':
            return self.reply(404, {'error': 'Not found'})
        origin = self.headers.get('Origin')
        if origin and urlparse(origin).netloc != self.headers.get('Host'):
            return self.reply(403, {'error': 'Use the same familyspace server address'})
        try:
            size = int(self.headers.get('Content-Length', 0))
            if not 1 <= size <= 8 * 1024 * 1024:
                return self.reply(413, {'error': 'Request too large'})
            batch = json.loads(self.rfile.read(size))
            status, result = self.server.store.change(batch)
            return self.reply(status, result)
        except PermissionError as error:
            return self.reply(403, {'error': str(error)})
        except (ValueError, TypeError, KeyError) as error:
            return self.reply(400, {'error': str(error)})


def main():
    parser = argparse.ArgumentParser(description='Run the shared familyspace demo')
    parser.add_argument('--host', default='0.0.0.0')
    parser.add_argument('--port', type=int, default=8000)
    parser.add_argument('--data', type=Path, default=ROOT / '.data' / 'familyspace.sqlite3')
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.daemon_threads = True
    server.store = Store(args.data)
    print(f'familyspace: http://localhost:{args.port}', flush=True)
    print('For other devices on the same Wi-Fi, use this computer’s local IP and the same port.', flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        server.store.db.close()


if __name__ == '__main__':
    main()
